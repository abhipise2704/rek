#Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#PDX-License-Identifier: MIT-0 (For details, see https://github.com/awsdocs/amazon-rekognition-custom-labels-developer-guide/blob/master/LICENSE-SAMPLECODE.)

import boto3
import io
from PIL import Image, ImageDraw, ExifTags, ImageColor, ImageFont
import streamlit as st
import pandas as pd 
import os





def display_image(bucket,photo,response):
    # Load image from S3 bucket
    s3_connection = boto3.resource('s3',region_name='ap-south-1',
                                   aws_access_key_id='AKIAZ6XSZXRSWLC7ADY3',
                                   aws_secret_access_key='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')

    s3_object = s3_connection.Object(bucket,photo)
    s3_response = s3_object.get()

    stream = io.BytesIO(s3_response['Body'].read())
    image=Image.open(stream)

    # Ready image to draw bounding boxes on it.
    imgWidth, imgHeight = image.size
    draw = ImageDraw.Draw(image)

    # calculate and display bounding boxes for each detected custom label
    print('Detected custom labels for ' + photo)
    for customLabel in response['CustomLabels']:
        print('Label ' + str(customLabel['Name']))
        print('Confidence ' + str(customLabel['Confidence']))
        if 'Geometry' in customLabel:
            box = customLabel['Geometry']['BoundingBox']
            left = imgWidth * box['Left']
            top = imgHeight * box['Top']
            width = imgWidth * box['Width']
            height = imgHeight * box['Height']

            fnt = ImageFont.load_default()
            draw.text((left,top), customLabel['Name'], fill='#00d400', font=fnt)

            print('Left: ' + '{0:.0f}'.format(left))
            print('Top: ' + '{0:.0f}'.format(top))
            print('Label Width: ' + "{0:.0f}".format(width))
            print('Label Height: ' + "{0:.0f}".format(height))

            points = (
                (left,top),
                (left + width, top),
                (left + width, top + height),
                (left , top + height),
                (left, top))
            draw.line(points, fill='#00d400', width=5)

    #image.show()
    folder="C:\\Users\\DR SNEHAL BANKAR\\Downloads\\streamlite_app\\saved_images"
    path=os.path.join(folder, photo)
    #st.text(path)
    image.save(path)
    image = Image.open(path)
    st.image(image, caption='Detectd BoundingBox on image')
    

def show_custom_labels(model,bucket,photo, min_confidence):
    client=boto3.client('rekognition',region_name='ap-south-1',
                        aws_access_key_id='AKIAZ6XSZXRSWLC7ADY3',
                        aws_secret_access_key='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')

    #Call DetectCustomLabels
    response = client.detect_custom_labels(Image={'S3Object': {'Bucket': bucket, 'Name': photo}},
        MinConfidence=min_confidence,
        ProjectVersionArn=model)
    
    #print(response)
    #response_json=json.dumps(response)
    #df=pd.DataFrame.from_dict(response)
    df_labels = pd.DataFrame(columns=['label','confidence'])

    for i in range(len(response['CustomLabels'])):
        df_labels.loc[len(df_labels.index)]=[str(response['CustomLabels'][i]['Name']),
                                             str(response['CustomLabels'][i]['Confidence'])]
    

    # For object detection use case, uncomment below code to display image.
    display_image(bucket,photo,response)
    

    return len(response['CustomLabels']),df_labels



 

    


def main():

    try:
        st.title('Eclerx Recognition')


        app_mode = st.sidebar.selectbox("Choose the app mode",
                                        ["Upload Image Mode", "Image click Mode"])
        if app_mode == "Upload Image Mode":    
             
            client_s3 = boto3.client('s3',
                                     region_name='ap-south-1',
                                     aws_access_key_id='AKIAZ6XSZXRSWLC7ADY3',
                                     aws_secret_access_key='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')


            #st.markdown('Streamlit is **_really_ cool**.')    
            inputFile = st.file_uploader("Image Uploader ",
                                        type = ["jpeg","png","jpg"])

            

            #Upload File to S3
            if inputFile is not None:
                imageFileName = inputFile.name
                #st.text("this is image name {}".format(imageFileName))
                client_s3.upload_file(imageFileName, 'teststreamlite', imageFileName)
                st.text('Image is Upload Complete.')#photo=upload_to_s3()




            if st.button('Detect label'):
                photo=imageFileName
                bucket='teststreamlite'
                model='arn:aws:rekognition:ap-south-1:684482739301:project/food_image_detection_sample/version/food_image_detection_sample.2021-07-14T19.13.45/1626270219163'
                min_confidence=30
                with st.spinner(text="Drawing Bounding Boxes"):
                    label_count , df_11 = show_custom_labels(model,bucket,photo, min_confidence)
                #print("Custom labels detected: " + str(label_count))
                st.subheader("Custom labels detected: " + str(label_count))
                st.dataframe(df_11)
                image = Image.open(photo)

                               
        else:
            #st.text("this is image click mode")
            image_name="482-4822222_burger-and-fries-png-vector-fdsf12oz-coke.png"
            img = Image.open(image_name)
            st.image(img)
            agree = st.button('Detect Label for Image 1')
            client_s3 = boto3.client('s3',
                                     region_name='ap-south-1',
                                     aws_access_key_id='AKIAZ6XSZXRSWLC7ADY3',
                                     aws_secret_access_key='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')
                     
            client_s3.upload_file(image_name, 'teststreamlite', image_name)
                #st.text('Image is Upload Complete.')#photo=upload_to_s3()

            if agree:
                photo=image_name
                bucket='teststreamlite'
                model='arn:aws:rekognition:ap-south-1:684482739301:project/food_image_detection_sample/version/food_image_detection_sample.2021-07-14T19.13.45/1626270219163'
                min_confidence=30
                with st.spinner(text="Drawing Bounding Boxes"):
                    label_count , df_11 = show_custom_labels(model,bucket,photo, min_confidence)
                #print("Custom labels detected: " + str(label_count))
                st.subheader("Custom labels detected: " + str(label_count))
                st.dataframe(df_11)
                
                st.balloons()

            

    except:
        st.text("image not uploaded yet")


if __name__ == "__main__":
    main()